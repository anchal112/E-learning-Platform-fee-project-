let menu=document.querySelector('#menu');
let navlist=document.querySelector('.navlist');

menu.onclick=() => {
    menu.classList.toggle('bx-x');
    navlist.classList.toggle('open');
}

var counter=1;
setInterval(function(){
    document.getElementById('radio' + counter).checked=true;
    counter++;if(counter>4){
        counter=1;
    }

},5000);